---
title:   平台即服务 (PaaS)
isChild: true
anchor:  platform_as_a_service
---

## Platform as a Service (PaaS) {#platform_as_a_service_title}

PaaS 提供了运行 PHP 应用程序所必须的系统环境和网络架构。这就意味着只需做少量配置就可以运行 PHP 应用程序或者 PHP 框架。

现在，PaaS 已经成为一种部署、托管和扩展各种规模的 PHP 应用程序的流行方式。你可以在 [资源部分](#resources) 查看 [PHP PaaS "Platform as a Service" 提供商](#php_paas_providers)  列表。
