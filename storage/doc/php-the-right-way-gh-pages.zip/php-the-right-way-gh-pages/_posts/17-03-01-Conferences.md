---
isChild: true
anchor:  conferences
title: PHP 大会
---

## PHP 会议 {#conferences_title}

世界各地的 PHP 社区也会举办一些较大型的区域性或国际性的会议，一些知名的社区成员通常会在这些大型活动中现身演讲，这是一个直接和业内领袖学习的好机会。

[查找 PHP 会议][php-conf]

[php-conf]: http://php.net/conferences/index.php
