---
isChild: true
title: PHP 官方
anchor:  from_the_source
---

## PHP 官方 {#from_the_source_title}

* [PHP 官方网站](http://php.net/)
* [PHP 官方文档](http://php.net/docs.php)
