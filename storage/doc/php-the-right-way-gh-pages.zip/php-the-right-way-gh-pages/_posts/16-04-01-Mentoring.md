---
isChild: true
anchor:  mentoring
title: 指导
---

## 指导 {#mentoring_title}

* [php-mentoring.org](http://php-mentoring.org/) - PHP 社区中的一对一指导。
