---
title: 值得关注的大牛
isChild: true
anchor:  people_to_follow
---

## 值得关注的大牛 {#people_to_follow_title}


刚进入社区时很难一下子找到很多有趣或者经验丰富的 PHP 社区成员，你可以在以下链接中找到 PHP 社区成员的 Twitter：

* [New Relic: 25 PHP Developers to Follow Online][php-developers-to-follow]
* [OGProgrammer: How to get connected with the PHP community][og-twitter-list]


[php-developers-to-follow]: https://blog.newrelic.com/2014/05/02/25-php-developers-follow-online/
[og-twitter-list]: https://www.ogprogrammer.com/2017/06/28/how-to-get-connected-with-the-php-community/


