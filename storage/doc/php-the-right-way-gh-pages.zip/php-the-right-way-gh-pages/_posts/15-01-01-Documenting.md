---
anchor: documenting
title:  代码注释
---

# 代码注释 {#documenting_title}
