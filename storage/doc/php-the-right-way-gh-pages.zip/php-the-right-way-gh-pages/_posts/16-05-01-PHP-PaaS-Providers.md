---
title: PHP Paas 提供商
isChild: true
anchor:  php_paas_providers
---

## PHP 的 Paas 提供商 {#php_paas_providers_title}

* [PagodaBox](https://pagodabox.io/)
* [AppFog](https://www.ctl.io/appfog/)
* [Heroku](https://devcenter.heroku.com/categories/php)
* [fortrabbit](https://www.fortrabbit.com/)
* [Engine Yard Cloud](https://www.engineyard.com/features)
* [Red Hat OpenShift Platform](https://www.openshift.com/)
* [AWS Elastic Beanstalk](https://aws.amazon.com/elasticbeanstalk/)
* [Windows Azure](http://www.windowsazure.com/)
* [Google App Engine](https://cloud.google.com/appengine/docs/php/)
* [Jelastic](http://jelastic.com/)
* [Platform.sh](https://platform.sh/)
* [Cloudways](https://www.cloudways.com/en/)
* [IBM Bluemix Cloud Foundry](https://console.ng.bluemix.net/)
* [Pivotal Web Service Cloud Foundry](https://run.pivotal.io/)

To see which versions these PaaS hosts are running, head over to [PHP Versions](http://phpversions.info/paas-hosting/).
