---
title: 服务器与部署
anchor: servers_and_deployment
---

# 服务器与部署 {#servers_and_deployment_title}

部署 PHP 应用程序到生产环境中有多种方式。
