---
isChild: true
anchor:  shared_servers
title: 共享服务器
---
## 共享主机 {#shared_servers_title}

PHP 非常流行，很少有服务器没有安装 PHP 的，因而有很多共享主机，不过需要注意服务器上的 PHP 是否是最新稳定 版本。共享主机允许多个开发者把自己的网站部署在上面，这样的好处是费用非常便宜，坏处是你不知道将和哪些 网站共享主机，因此需要仔细考虑机器负载和安全问题。如果项目预算允许的话，避免使用共享主机是上策。

为确保你的共享主机使用了最新的 PHP 版本，请查看：[共享主机 PHP 版本使用](http://phpversions.info/shared-hosting/).
