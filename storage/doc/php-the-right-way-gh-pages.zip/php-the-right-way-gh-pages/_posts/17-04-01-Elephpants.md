---
isChild: true
anchor:  elephpants
---

## ElePHPants {#elephpants_title}

[ElePHPant][elephpant] is that beautiful mascot of the PHP project with elephant in their design. It was originally designed for the PHP project in 1998 by [Vincent Pontier][vincent-pontier] - spiritual father of thousands of elePHPants around the world and 10 years later adorable plush elephant toy came to birth as well. Now elePHPants are present at many PHP conferences and with many PHP developers at their computers for fun and inspiration.

[Interview with Vincent Pontier][vincent-pontier-interview]


[elephpant]: http://php.net/elephpant.php
[vincent-pontier-interview]: http://7php.com/elephpant/
[vincent-pontier]: http://www.elroubio.net/
