---
title:  使用模板
anchor: templating
---

# 使用模板 {#templating_title}

模板提供了一种简便的方式，将展现逻辑从控制器和业务逻辑中分离出来。

一般来说，模板包含应用程序的 HTML 代码，但也可以使用其他的格式，例如 XML 。

模板通常也被称为「视图」, 而它是 [模型-视图-控制器](/pages/Design-Patterns.html#model-view-controller) (MVC) 软件架构模式第二个元素的 **一部份** 。
